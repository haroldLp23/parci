﻿using System;

namespace  ProyectoVenta.datos
{
    public class Conexion1
    {
        private string cadenaSQL = string.Empty;
        public Conexion1()

        {


            var builder = new ConfigurationBuilder().
                SetBasePath(Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.json").Build();

            cadenaSQL = builder.GetSection("ConnectionStrings:CadenasSQL").Value;

        }
    
        public string getCadenaSQL()
        {
            return cadenaSQL;
        }
            
    }
}

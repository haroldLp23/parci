using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ventas_aplicaccion_1.Views.inventario
{
    public class ProductosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

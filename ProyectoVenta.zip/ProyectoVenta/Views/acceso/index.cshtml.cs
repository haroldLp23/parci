using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ventas_aplicaccion_1.Views.acceso
{
    public class indexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

﻿namespace ProyectoVenta.Models
{
    public class autocomplete
    {
        public string label { get; set; }
        public int value { get; set; }
    }
}

﻿namespace ventas_aplicaccion_1.Models
{
    public class Usuario
    {
        public int Idusuario { get; set; }

        public string NombreCompleto { get; set; }

        public string Correo { get; set; }

        public string Clave { get; set; }

    }
}

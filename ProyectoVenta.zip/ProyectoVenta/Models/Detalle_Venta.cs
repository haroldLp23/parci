﻿using System.ComponentModel;
using ventas_aplicaccion_1.Models;

namespace ProyectoVenta.Models
{
    public class Detalle_Venta
    {
        public int IdDetalleVenta { get; set; }

        public   Producto oProducto { get; set; }

        public decimal Pre3cioVenta { get; set; }

        public int Cantidad { get; set; }

        public decimal Total { get; set; }
    }
}
